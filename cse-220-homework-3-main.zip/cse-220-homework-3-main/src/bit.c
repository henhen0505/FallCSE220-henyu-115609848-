#include <stdio.h>
#include <stdlib.h>
#include <bit.h>

// Students should fill in bodies of the functions below.

int ToggleBit(int num, int pos)
{
	// Students should implement here!
	return 0; 
}

int GetMSB(int num)
{
	return 0;
}

int ClearBitRange(int num, int start, int end)
{
	return 0;
}

int RotateLeft(int num, int d)
{
	return 0;
}

int SwapOddEvenBits(int num)
{
	return 0;
}

/**
 * Create all test cases inside of the main function below.
 * Run the test cases by first compiling with "make" and then 
 * running "./build/bit"
 * 
 * Before submmiting your assignment, please comment out your 
 * test cases for the TAs.
 */
int main(int argc, char* argv[]){
	(void)argc;
	(void)argv;
	/** CREATE TEST CASES HERE **/



	
	/** ---------------------- **/
	return 0;
}