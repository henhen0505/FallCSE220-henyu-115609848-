#include <stdio.h>
#include <stdlib.h>
#include <integer.h>

// FILL IN THE BODY OF THIS FUNCTION.
// Feel free to create any other functions you like; just include them in this file.



void repr_convert(char source_repr, char target_repr, unsigned int repr) {

}


/**
 * Create all test cases inside of the main function below.
 * Run the test cases by first compiling with "make" and then 
 * running "./build/integer"
 * 
 * Before submmiting your assignment, please comment out your 
 * test cases for the TAs.
 */
int main(int argc, char* argv[]){
	(void)argc;
	(void)argv;
	/** CREATE TEST CASES HERE **/



	
	/** ---------------------- **/
	return 0;
}
